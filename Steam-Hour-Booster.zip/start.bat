@echo off
cd /d "%~dp0"
title Steam Hour Booster 24/7 - Developed by Ahmad
cls
echo ===================================================
echo               Steam Hour Booster 24/7
echo                  Developed by Ahmad
echo ===================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [!] Node.js is not installed!
    echo Please install Node.js (LTS) from: https://nodejs.org
    echo.
    pause
    exit /b
)

if not exist "node_modules\" (
    echo [i] First time setup: Installing dependencies, please wait...
    call npm install
    echo.
)

echo [OK] Launching Steam Booster...
if exist "Steam Booster.exe" (
    start "" "Steam Booster.exe"
) else (
    start "" "http://localhost:3000"
    node index.js
)