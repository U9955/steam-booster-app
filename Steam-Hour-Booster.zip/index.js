const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { exec, spawn } = require('child_process');
const express = require('express');
const SteamUser = require('steam-user');
const { LoginSession, EAuthTokenPlatformType } = require('steam-session');
require('dotenv').config();

const CONFIG_PATH = path.join(__dirname, 'config.json');

// Global state
let botInstances = new Map(); // accountName -> { client, startTime, config, connected, steamID, logs }
let pendingLogins = new Map(); // accountName -> { client, resolveGuard }
const globalLogs = [];

function addGlobalLog(msg) {
    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    const logLine = `[${timestamp}] ${msg}`;
    console.log(logLine);
    globalLogs.unshift(logLine);
    if (globalLogs.length > 40) globalLogs.pop();
}

function loadConfig() {
    let config = {
        developer: "Ahmad",
        port: process.env.PORT || 3000,
        accounts: []
    };

    if (fs.existsSync(CONFIG_PATH)) {
        try {
            const fileData = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
            // Migration support for legacy single-account configs
            if (fileData.accounts && Array.isArray(fileData.accounts)) {
                config = { ...config, ...fileData };
            } else if (fileData.accountName) {
                config.developer = "Ahmad";
                config.port = fileData.port || 3000;
                config.accounts = [{
                    accountName: fileData.accountName,
                    refreshToken: fileData.refreshToken || '',
                    games: fileData.games || [730, 359550, 271590],
                    invisible: fileData.invisible || false
                }];
            }
        } catch (e) {
            console.error('⚠️ خطأ في قراءة config.json:', e.message);
        }
    }

    config.developer = "Ahmad"; // Ensure Ahmad credits are permanently set
    return config;
}

let config = loadConfig();

function saveConfig() {
    try {
        config.developer = "Ahmad";
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
    } catch (e) {
        console.error('⚠️ تعذر حفظ config.json:', e.message);
    }
}

// Helper to start or update idling for an account
function startBotForAccount(accConfig) {
    const accName = accConfig.accountName;
    if (botInstances.has(accName)) {
        const existing = botInstances.get(accName);
        if (existing.connected) {
            existing.client.gamesPlayed(accConfig.games.slice(0, 32), true);
            return existing;
        }
    }

    const client = new SteamUser();
    const botData = {
        client: client,
        startTime: Date.now(),
        config: accConfig,
        connected: false,
        paused: false,
        steamID: '',
        logs: []
    };
    botInstances.set(accName, botData);

    client.on('loggedOn', () => {
        botData.connected = true;
        if (botData.reconnectTimer) {
            clearTimeout(botData.reconnectTimer);
            botData.reconnectTimer = null;
        }
        botData.steamID = client.steamID.getSteamID64();
        addGlobalLog(`✅ [${accName}] Logged in successfully! SteamID: ${botData.steamID}`);

        const persona = accConfig.invisible ? SteamUser.EPersonaState.Invisible : SteamUser.EPersonaState.Online;
        client.setPersona(persona);

        if (!botData.paused) {
            client.gamesPlayed((accConfig.games || []).slice(0, 32), true);
            addGlobalLog(`🎮 [${accName}] Now idling ${accConfig.games.length} games.`);
        } else {
            client.gamesPlayed([]);
            addGlobalLog(`⏸️ [${accName}] Logged in (Paused for Gaming).`);
        }
    });

    client.on('refreshToken', (token) => {
        addGlobalLog(`🔑 [${accName}] Refresh token received and saved securely!`);
        accConfig.refreshToken = token;
        saveConfig();
    });

    function scheduleReconnect() {
        if (botData.reconnectTimer) return;
        addGlobalLog(`🔄 [${accName}] Connection lost. Reconnecting in 8 seconds...`);
        botData.reconnectTimer = setTimeout(() => {
            botData.reconnectTimer = null;
            if (accConfig.refreshToken && accConfig.refreshToken.trim() !== '') {
                addGlobalLog(`[${accName}] Reconnecting with saved Refresh Token...`);
                try { client.logOff(); } catch (e) {}
                client.logOn({ refreshToken: accConfig.refreshToken.trim() });
            }
        }, 8000);
    }

    client.on('error', (err) => {
        addGlobalLog(`❌ [${accName}] Error: ${err.message}`);
        botData.connected = false;

        if (err.eresult === SteamUser.EResult.InvalidPassword) {
            addGlobalLog(`⚠️ [${accName}] Invalid password or revoked token.`);
            accConfig.refreshToken = '';
            saveConfig();
            return;
        }

        scheduleReconnect();
    });

    client.on('disconnected', (eresult, msg) => {
        addGlobalLog(`⚠️ [${accName}] Disconnected (${msg || eresult}).`);
        botData.connected = false;
        scheduleReconnect();
    });

    // Login using refreshToken if available
    if (accConfig.refreshToken && accConfig.refreshToken.trim() !== '') {
        addGlobalLog(`[${accName}] Logging in with saved Refresh Token...`);
        client.logOn({
            refreshToken: accConfig.refreshToken.trim()
        });
    }

    return botData;
}

// -------------------------------------------------------------
// 1. Web Launcher & APIs
// -------------------------------------------------------------
const app = express();
app.use(express.json());
const PORT = process.env.PORT || config.port || 3000;

// API: Get Status of All Accounts
app.get('/api/status', (req, res) => {
    const accountsData = config.accounts.map(acc => {
        const bot = botInstances.get(acc.accountName);
        const uptimeSeconds = bot && bot.connected ? Math.floor((Date.now() - bot.startTime) / 1000) : 0;
        return {
            accountName: acc.accountName,
            steamID: bot ? bot.steamID : '',
            connected: bot ? bot.connected : false,
            paused: bot ? !!bot.paused : false,
            games: acc.games || [],
            invisible: acc.invisible || false,
            uptimeSeconds: uptimeSeconds
        };
    });

    res.json({
        developer: "Ahmad",
        accounts: accountsData,
        logs: globalLogs
    });
});

// API: Search Steam Store for Games
app.get('/api/search', async (req, res) => {
    const q = req.query.q;
    if (!q || q.trim().length === 0) return res.json({ items: [] });

    try {
        const response = await fetch(`https://store.steampowered.com/api/storesearch/?term=${encodeURIComponent(q)}&l=english&cc=US`);
        const data = await response.json();
        const items = (data.items || []).map(item => ({
            id: item.id,
            name: item.name,
            tiny_image: item.tiny_image
        }));
        res.json({ items });
    } catch (e) {
        res.status(500).json({ error: 'Search failed' });
    }
});

// API: Game Info & Official High-Res Images Cache
const gameCache = {};

app.get('/api/game-info/:appid', async (req, res) => {
    const appid = req.params.appid;
    if (gameCache[appid]) {
        return res.json(gameCache[appid]);
    }

    try {
        const response = await fetch(`https://store.steampowered.com/api/appdetails?appids=${appid}&l=english`);
        const data = await response.json();
        if (data && data[appid] && data[appid].success && data[appid].data) {
            const g = data[appid].data;
            const info = {
                id: parseInt(appid, 10),
                name: g.name,
                image: g.header_image || `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/${appid}/header.jpg`
            };
            gameCache[appid] = info;
            return res.json(info);
        }
    } catch (e) {
        console.error(`Error fetching game info for ${appid}:`, e.message);
    }

    const fallback = {
        id: parseInt(appid, 10),
        name: `AppID: ${appid}`,
        image: `https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/${appid}/header.jpg`
    };
    gameCache[appid] = fallback;
    res.json(fallback);
});

// API: Add Game to Account
app.post('/api/games/add', (req, res) => {
    const { accountName, appid } = req.body;
    const cleanAppId = parseInt(appid, 10);
    const acc = config.accounts.find(a => a.accountName === accountName);

    if (!acc) return res.status(404).json({ error: 'الحساب غير موجود' });
    if (!cleanAppId || isNaN(cleanAppId)) return res.status(400).json({ error: 'رقم AppID غير صالح' });
    if (acc.games.includes(cleanAppId)) return res.status(400).json({ error: 'اللعبة مضافة بالفعل لهذا الحساب!' });
    if (acc.games.length >= 32) return res.status(400).json({ error: 'الحد الأقصى هو 32 لعبة في نفس الوقت!' });

    acc.games.push(cleanAppId);
    saveConfig();

    const bot = botInstances.get(accountName);
    if (bot) {
        if (bot.connected) {
            bot.client.gamesPlayed(acc.games.slice(0, 32), true);
        } else if (acc.refreshToken) {
            bot.client.logOn({ refreshToken: acc.refreshToken.trim() });
        }
    }
    addGlobalLog(`➕ [${accountName}] Added game (AppID: ${cleanAppId})`);
    res.json({ success: true, games: acc.games });
});

// API: Remove Game from Account
app.post('/api/games/remove', (req, res) => {
    const { accountName, appid } = req.body;
    const cleanAppId = parseInt(appid, 10);
    const acc = config.accounts.find(a => a.accountName === accountName);

    if (!acc) return res.status(404).json({ error: 'الحساب غير موجود' });

    acc.games = acc.games.filter(id => id !== cleanAppId);
    saveConfig();

    const bot = botInstances.get(accountName);
    if (bot) {
        if (bot.connected) {
            bot.client.gamesPlayed(acc.games.slice(0, 32), true);
        } else if (acc.refreshToken) {
            bot.client.logOn({ refreshToken: acc.refreshToken.trim() });
        }
    }
    addGlobalLog(`➖ [${accountName}] Removed game (AppID: ${cleanAppId})`);
    res.json({ success: true, games: acc.games });
});

// API: Toggle Invisible Mode
app.post('/api/settings', (req, res) => {
    const { accountName, invisible } = req.body;
    const acc = config.accounts.find(a => a.accountName === accountName);
    if (!acc) return res.status(404).json({ error: 'الحساب غير موجود' });

    acc.invisible = invisible;
    saveConfig();

    const bot = botInstances.get(accountName);
    if (bot && bot.connected) {
        const persona = invisible ? SteamUser.EPersonaState.Invisible : SteamUser.EPersonaState.Online;
        bot.client.setPersona(persona);
    }
    addGlobalLog(`⚙️ [${accountName}] Invisible mode: ${invisible ? 'Enabled' : 'Disabled'}`);
    res.json({ success: true, invisible: acc.invisible });
});

// API: Add New Steam Account
app.post('/api/accounts/login', (req, res) => {
    const { accountName, password, guardCode } = req.body;
    if (!accountName) return res.status(400).json({ error: 'ادخل اسم المستخدم' });

    const trimmedUser = accountName.trim();

    // Check if waiting for guard
    if (pendingLogins.has(trimmedUser) && guardCode) {
        const pending = pendingLogins.get(trimmedUser);
        if (pending.resolveGuard) {
            pending.resolveGuard(guardCode.trim());
            return res.json({ status: 'authenticating', message: 'جاري التحقق من الكود...' });
        }
    }

    if (!password) return res.status(400).json({ error: 'ادخل كلمة المرور' });

    // Initiate new login
    const client = new SteamUser();
    let isHandled = false;

    pendingLogins.set(trimmedUser, {
        client: client,
        resolveGuard: null
    });

    client.on('loggedOn', () => {
        isHandled = true;
        addGlobalLog(`✅ [${trimmedUser}] New account logged in successfully!`);

        // Check if account already in config
        let accConfig = config.accounts.find(a => a.accountName.toLowerCase() === trimmedUser.toLowerCase());
        if (!accConfig) {
            accConfig = {
                accountName: trimmedUser,
                refreshToken: '',
                games: [730, 359550, 271590],
                invisible: false
            };
            config.accounts.push(accConfig);
        }

        botInstances.set(trimmedUser, {
            client: client,
            startTime: Date.now(),
            config: accConfig,
            connected: true,
            steamID: client.steamID.getSteamID64(),
            logs: []
        });

        client.setPersona(SteamUser.EPersonaState.Online);
        client.gamesPlayed(accConfig.games.slice(0, 32), true);
        pendingLogins.delete(trimmedUser);
        saveConfig();

        if (!res.headersSent) {
            res.json({ status: 'success', accountName: trimmedUser });
        }
    });

    client.on('refreshToken', (token) => {
        let accConfig = config.accounts.find(a => a.accountName.toLowerCase() === trimmedUser.toLowerCase());
        if (accConfig) {
            accConfig.refreshToken = token;
            saveConfig();
        }
    });

    client.on('steamGuard', (domain, callback) => {
        addGlobalLog(`🔒 [${trimmedUser}] Steam Guard Code required!`);
        const pending = pendingLogins.get(trimmedUser);
        if (pending) {
            pending.resolveGuard = callback;
        }
        if (!res.headersSent) {
            res.json({
                status: 'need_guard',
                domain: domain || 'Mobile Authenticator',
                message: domain ? `أدخل الكود المرسل إلى بريدك (${domain})` : 'أدخل كود تطبيق الهاتف (Steam Mobile App)'
            });
        }
    });

    client.on('error', (err) => {
        addGlobalLog(`❌ [${trimmedUser}] Login failed: ${err.message}`);
        pendingLogins.delete(trimmedUser);
        if (!res.headersSent) {
            res.status(400).json({ status: 'error', error: err.message });
        }
    });

    addGlobalLog(`[${trimmedUser}] Initiating login...`);
    client.logOn({
        accountName: trimmedUser,
        password: password.trim()
    });
});

// API: Remove Account
app.post('/api/accounts/remove', (req, res) => {
    const { accountName } = req.body;
    config.accounts = config.accounts.filter(a => a.accountName !== accountName);
    saveConfig();

    if (botInstances.has(accountName)) {
        const bot = botInstances.get(accountName);
        try { bot.client.logOff(); } catch (e) {}
        botInstances.delete(accountName);
    }

    addGlobalLog(`🗑️ [${accountName}] Account removed from booster.`);
    res.json({ success: true });
});

// -------------------------------------------------------------
// QR Code Steam Login System
// -------------------------------------------------------------
let activeQrSession = null;
let qrStatus = { state: 'idle', challengeUrl: null, accountName: null, error: null };

app.get('/api/qr/start', async (req, res) => {
    try {
        if (activeQrSession) {
            try { activeQrSession.cancelLoginAttempt(); } catch (e) {}
            activeQrSession = null;
        }

        activeQrSession = new LoginSession(EAuthTokenPlatformType.SteamClient);
        const qrResult = await activeQrSession.startWithQR();
        
        qrStatus = {
            state: 'waiting_scan',
            challengeUrl: qrResult.qrChallengeUrl,
            accountName: null,
            error: null
        };

        addGlobalLog('📱 Generated Steam QR Code! Waiting for mobile scan...');

        activeQrSession.on('authenticated', () => {
            const newAccName = activeQrSession.accountName;
            const token = activeQrSession.refreshToken;
            addGlobalLog(`✅ [${newAccName}] Authenticated via QR Code successfully!`);

            let acc = config.accounts.find(a => a.accountName.toLowerCase() === newAccName.toLowerCase());
            if (!acc) {
                acc = {
                    accountName: newAccName,
                    refreshToken: token,
                    games: [730, 359550, 271590],
                    invisible: false
                };
                config.accounts.push(acc);
            } else {
                acc.refreshToken = token;
            }
            saveConfig();
            startBotForAccount(acc);

            qrStatus = { state: 'authenticated', accountName: newAccName, error: null };
        });

        activeQrSession.on('timeout', () => {
            addGlobalLog('⚠️ Steam QR Code session expired.');
            qrStatus = { state: 'timeout', error: 'انتهت صلاحية الرمز. اضغط إعادة المحاولة.' };
        });

        activeQrSession.on('error', (err) => {
            addGlobalLog(`❌ Steam QR Code error: ${err.message}`);
            qrStatus = { state: 'error', error: err.message };
        });

        res.json({ success: true, challengeUrl: qrResult.qrChallengeUrl });
    } catch (e) {
        addGlobalLog(`❌ Failed to generate QR session: ${e.message}`);
        res.status(500).json({ error: e.message });
    }
});

app.get('/api/qr/status', (req, res) => {
    res.json(qrStatus);
});

// API: Toggle Pause / Resume Idling for an Account
app.post('/api/accounts/toggle-pause', (req, res) => {
    const { accountName } = req.body;
    if (!accountName) return res.status(400).json({ error: 'accountName is required' });
    const bot = botInstances.get(accountName);
    if (!bot) return res.status(404).json({ error: 'Account not active' });

    bot.paused = !bot.paused;
    if (bot.paused) {
        bot.client.gamesPlayed([]);
        addGlobalLog(`⏸️ [${accountName}] Idling PAUSED (games released for Steam client).`);
    } else {
        bot.client.gamesPlayed((bot.config.games || []).slice(0, 32), true);
        addGlobalLog(`▶️ [${accountName}] Idling RESUMED (${(bot.config.games || []).length} games).`);
    }
    res.json({ success: true, paused: bot.paused });
});

// HTML Launcher Interface with Multi-Account & Ahmad Credits
app.get('/', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Steam Hour Booster - Developed by Ahmad</title>
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
        <style>
            * { box-sizing: border-box; }
            body {
                font-family: 'Tajawal', sans-serif;
                background: #080c14;
                color: #e2e8f0;
                margin: 0;
                padding: 20px;
            }
            .wrapper { max-width: 960px; margin: auto; }
            
            /* Header with Developer Credit */
            .header {
                background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%);
                padding: 24px 28px;
                border-radius: 16px;
                display: flex;
                flex-wrap: wrap;
                justify-content: space-between;
                align-items: center;
                border: 1px solid #312e81;
                margin-bottom: 22px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            }
            .header-titles h1 { margin: 0; font-size: 26px; color: #38bdf8; display: flex; align-items: center; gap: 10px; }
            .dev-badge {
                background: linear-gradient(90deg, #818cf8 0%, #c084fc 100%);
                color: #0f172a;
                font-weight: 900;
                padding: 4px 12px;
                border-radius: 20px;
                font-size: 13px;
                box-shadow: 0 0 15px rgba(192, 132, 252, 0.4);
                display: inline-flex;
                align-items: center;
                gap: 5px;
            }
            .header-sub { font-size: 13px; color: #94a3b8; margin-top: 6px; }

            /* Account Tabs */
            .accounts-tabs-bar {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
                margin-bottom: 22px;
                align-items: center;
            }
            .acc-tab {
                background: #1e293b;
                border: 1px solid #334155;
                color: #cbd5e1;
                padding: 10px 18px;
                border-radius: 12px;
                font-family: inherit;
                font-weight: 700;
                font-size: 14px;
                cursor: pointer;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                transition: 0.2s;
            }
            .acc-tab:hover { background: #334155; }
            .acc-tab.active {
                background: #0284c7;
                color: #fff;
                border-color: #38bdf8;
                box-shadow: 0 0 18px rgba(2, 132, 199, 0.4);
            }
            .acc-tab .dot {
                width: 10px; height: 10px; border-radius: 50%; display: inline-block;
            }
            .dot-green { background: #22c55e; box-shadow: 0 0 8px #22c55e; }
            .dot-yellow { background: #eab308; box-shadow: 0 0 8px #eab308; }
            .dot-red { background: #ef4444; }
            .add-acc-btn {
                background: rgba(34, 197, 94, 0.15);
                border: 1px dashed #22c55e;
                color: #4ade80;
                padding: 10px 18px;
                border-radius: 12px;
                cursor: pointer;
                font-family: inherit;
                font-weight: 700;
                font-size: 14px;
                transition: 0.2s;
            }
            .add-acc-btn:hover { background: #22c55e; color: #052e16; }

            /* Stats */
            .stats-bar {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 14px;
                margin-bottom: 24px;
            }
            .stat-card {
                background: #111827;
                padding: 16px;
                border-radius: 12px;
                border: 1px solid #1f2937;
                text-align: center;
            }
            .stat-card .val { font-size: 20px; font-weight: 800; color: #38bdf8; margin-top: 5px; }
            .stat-card .label { font-size: 13px; color: #9ca3af; }

            .section-box {
                background: #111827;
                padding: 22px;
                border-radius: 14px;
                border: 1px solid #1f2937;
                margin-bottom: 22px;
            }
            .section-box h2 {
                margin-top: 0;
                font-size: 18px;
                color: #f3f4f6;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }

            /* Search & Add */
            .search-box { position: relative; margin-bottom: 15px; }
            .search-box input {
                width: 100%;
                padding: 14px 20px;
                border-radius: 10px;
                border: 1px solid #374151;
                background: #0b0f19;
                color: #fff;
                font-size: 15px;
                font-family: inherit;
                outline: none;
                transition: 0.2s;
            }
            .search-box input:focus { border-color: #38bdf8; box-shadow: 0 0 0 3px rgba(56, 189, 248, 0.2); }
            
            .search-results {
                position: absolute;
                top: 100%; left: 0; right: 0;
                background: #1f2937;
                border: 1px solid #374151;
                border-radius: 10px;
                max-height: 280px;
                overflow-y: auto;
                z-index: 50;
                display: none;
                box-shadow: 0 15px 35px rgba(0,0,0,0.6);
            }
            .search-item {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 10px 15px;
                border-bottom: 1px solid #374151;
                transition: 0.15s;
            }
            .search-item:hover { background: #374151; }
            .search-item-info { display: flex; align-items: center; gap: 12px; }
            .search-item img { width: 50px; height: 24px; object-fit: cover; border-radius: 4px; }
            
            .btn {
                padding: 8px 16px;
                border-radius: 8px;
                border: none;
                cursor: pointer;
                font-family: inherit;
                font-weight: 700;
                font-size: 13px;
                transition: 0.2s;
            }
            .btn-primary { background: #0284c7; color: #fff; }
            .btn-primary:hover { background: #0369a1; }
            .btn-danger { background: rgba(239, 68, 68, 0.2); color: #f87171; border: 1px solid #ef4444; }
            .btn-danger:hover { background: #ef4444; color: #fff; }

            .quick-picks { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; }
            .quick-btn {
                background: #0b0f19;
                border: 1px solid #374151;
                color: #d1d5db;
                padding: 6px 12px;
                border-radius: 20px;
                font-size: 12px;
                cursor: pointer;
                transition: 0.15s;
            }
            .quick-btn:hover { background: #38bdf8; color: #080c14; border-color: #38bdf8; font-weight: bold; }

            /* Games Grid */
            .games-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                gap: 15px;
            }
            .game-card {
                background: #0b0f19;
                border-radius: 10px;
                overflow: hidden;
                border: 1px solid #374151;
                display: flex;
                flex-direction: column;
                transition: 0.2s;
            }
            .game-card:hover { transform: translateY(-3px); border-color: #38bdf8; }
            .game-card img { width: 100%; height: 110px; object-fit: cover; background: #1f2937; }
            .game-card-body { padding: 12px; display: flex; justify-content: space-between; align-items: center; }
            .game-card-title { font-weight: 700; font-size: 14px; }
            .game-card-sub { font-size: 12px; color: #9ca3af; }

            /* Modal for Add Account */
            .modal-overlay {
                position: fixed; top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0,0,0,0.8);
                display: none;
                justify-content: center;
                align-items: center;
                z-index: 100;
                padding: 20px;
            }
            .modal-box {
                background: #111827;
                border: 1px solid #374151;
                padding: 25px;
                border-radius: 16px;
                max-width: 440px;
                width: 100%;
                box-shadow: 0 20px 40px rgba(0,0,0,0.8);
            }
            .modal-box h3 { margin-top: 0; color: #38bdf8; font-size: 20px; }
            .form-group { margin-bottom: 15px; }
            .form-group label { display: block; font-size: 13px; margin-bottom: 6px; color: #9ca3af; }
            .form-group input {
                width: 100%;
                padding: 12px 14px;
                border-radius: 8px;
                border: 1px solid #374151;
                background: #080c14;
                color: #fff;
                font-family: inherit;
                font-size: 14px;
                outline: none;
            }
            .form-group input:focus { border-color: #38bdf8; }

            .toggle-container {
                display: flex; align-items: center; gap: 12px;
                background: #0b0f19; padding: 12px 18px; border-radius: 10px; border: 1px solid #374151;
            }
            .switch { position: relative; display: inline-block; width: 48px; height: 26px; }
            .switch input { opacity: 0; width: 0; height: 0; }
            .slider {
                position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
                background-color: #4b5563; transition: .3s; border-radius: 34px;
            }
            .slider:before {
                position: absolute; content: ""; height: 18px; width: 18px; left: 4px; bottom: 4px;
                background-color: white; transition: .3s; border-radius: 50%;
            }
            input:checked + .slider { background-color: #22c55e; }
            input:checked + .slider:before { transform: translateX(22px); }

            .logs-box {
                background: #050811;
                border-radius: 8px;
                padding: 12px;
                font-family: monospace;
                font-size: 12px;
                max-height: 160px;
                overflow-y: auto;
                color: #38bdf8;
            }
            
            .footer-credit {
                text-align: center;
                padding: 20px 0;
                color: #6b7280;
                font-size: 13px;
            }
            .footer-credit strong { color: #c084fc; font-weight: 700; }

            /* Telegram Contact Button */
            .tg-contact-btn {
                background: linear-gradient(135deg, #0088cc 0%, #29b6f6 100%);
                color: #fff;
                text-decoration: none;
                padding: 9px 16px;
                border-radius: 12px;
                font-weight: 700;
                font-size: 13px;
                display: inline-flex;
                align-items: center;
                gap: 8px;
                box-shadow: 0 4px 15px rgba(0, 136, 204, 0.35);
                transition: all 0.25s ease;
                border: 1px solid rgba(255,255,255,0.25);
            }
            .tg-contact-btn:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(41, 182, 246, 0.6);
                color: #fff;
            }
            .tg-contact-btn svg {
                width: 18px;
                height: 18px;
                fill: currentColor;
            }

            .lang-btn {
                background: #1e293b;
                border: 1px solid #475569;
                color: #e2e8f0;
                padding: 9px 15px;
                border-radius: 12px;
                cursor: pointer;
                font-family: inherit;
                font-weight: 700;
                font-size: 13px;
                display: inline-flex;
                align-items: center;
                gap: 6px;
                transition: 0.2s;
            }
            .lang-btn:hover {
                background: #334155;
                border-color: #38bdf8;
                color: #38bdf8;
            }
        </style>
    </head>
    <body>
        <div class="wrapper">
            <!-- Header -->
            <div class="header">
                <div class="header-titles">
                    <h1>
                        <span>🎮 Steam Hour Booster</span>
                        <span class="dev-badge">👑 By Ahmad</span>
                    </h1>
                    <div class="header-sub" data-i18n="headerSub">نظام زيادة ساعات ألعاب ستيم المتكامل 24/7</div>
                </div>

                <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                    <!-- Language Switcher Button -->
                    <button id="langToggleBtn" onclick="toggleLanguage()" class="lang-btn">
                        <span>🌐 English</span>
                    </button>

                    <!-- Telegram Contact Button -->
                    <a href="https://t.me/u9955" target="_blank" class="tg-contact-btn">
                        <svg viewBox="0 0 24 24">
                            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.75-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .37z"/>
                        </svg>
                        <span data-i18n="contactUs">تواصل معنا</span>
                    </a>
                </div>
            </div>

            <!-- Accounts Switcher Tabs -->
            <div class="accounts-tabs-bar" id="accountsTabsBar">
                    <!-- Account tabs dynamically generated here -->
                </div>

                <!-- Stats Bar -->
                <div class="stats-bar">
                    <div class="stat-card">
                        <div class="label" data-i18n="statSelectedAcc">الحساب المحدد</div>
                        <div class="val" id="selectedAccName">--</div>
                    </div>
                    <div class="stat-card">
                        <div class="label" data-i18n="statSteamID">معرف الحساب (SteamID)</div>
                        <div class="val" id="accSteamID" style="font-size: 15px;">--</div>
                    </div>
                    <div class="stat-card">
                        <div class="label" data-i18n="statGamesCount">ألعاب هذا الحساب</div>
                        <div class="val" id="gamesCount">0 / 32</div>
                    </div>
                    <div class="stat-card">
                        <div class="label" data-i18n="statUptime">مدة التشغيل المستمرة</div>
                        <div class="val" id="uptimeVal">00:00:00</div>
                    </div>
                </div>

                <!-- Add Games Section -->
                <div class="section-box">
                    <h2 data-i18n="addGameTitle">➕ إضافة لعبة للحساب المحدد</h2>
                    
                    <div class="search-box">
                        <input type="text" id="gameSearchInput" placeholder="ابحث باسم اللعبة (مثال: Rainbow, GTA, Rust, CS, Battlefield)..." autocomplete="off">
                        <div id="searchResults" class="search-results"></div>
                    </div>

                    <div style="font-size: 13px; color: #9ca3af; margin-bottom: 8px;" data-i18n="quickPicksLabel">أو اختر من أشهر الألعاب مباشرة بضغطة زر:</div>
                    <div class="quick-picks">
                        <button class="quick-btn" onclick="addGame(730)">+ CS2 (730)</button>
                        <button class="quick-btn" onclick="addGame(359550)">+ Rainbow Six (359550)</button>
                        <button class="quick-btn" onclick="addGame(271590)">+ GTA V (271590)</button>
                        <button class="quick-btn" onclick="addGame(252490)">+ Rust (252490)</button>
                        <button class="quick-btn" onclick="addGame(1172470)">+ Apex Legends (1172470)</button>
                        <button class="quick-btn" onclick="addGame(578080)">+ PUBG (578080)</button>
                        <button class="quick-btn" onclick="addGame(570)">+ Dota 2 (570)</button>
                        <button class="quick-btn" onclick="addGame(440)">+ TF2 (440)</button>
                        <button class="quick-btn" onclick="addGame(227300)">+ Euro Truck Sim 2 (227300)</button>
                        <button class="quick-btn" onclick="addGame(105600)">+ Terraria (105600)</button>
                    </div>
                </div>

                <!-- Active Games Section -->
                <div class="section-box">
                    <h2>
                        <span data-i18n="activeGamesTitle">الألعاب المفعلة لهذا الحساب</span>
                        <span style="font-size: 13px; font-weight: normal; color: #38bdf8;" id="gamesLimitTxt"></span>
                    </h2>
                    <div id="gamesGrid" class="games-grid"></div>
                </div>

                <!-- Settings -->
                <div class="section-box">
                    <h2 data-i18n="settingsTitle">⚙️ إعدادات الحساب المحدد</h2>
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <div class="toggle-container" style="flex: 1; min-width: 250px;">
                            <label class="switch">
                                <input type="checkbox" id="invisibleToggle" onchange="toggleInvisible(this.checked)">
                                <span class="slider"></span>
                            </label>
                            <div>
                                <strong data-i18n="invisibleTitle">وضع التخفي (Invisible Mode)</strong>
                                <div style="font-size: 12px; color: #9ca3af;" data-i18n="invisibleSub">إخفاء إشارة اللعبة الخضراء عن أصدقائك في هذا الحساب.</div>
                            </div>
                        </div>

                        <!-- Pause / Resume Button -->
                        <button id="pauseToggleBtn" class="btn" style="background: rgba(234, 179, 8, 0.2); color: #facc15; border: 1px solid #eab308; padding: 10px 18px; font-size: 13px;" onclick="togglePauseCurrentAccount()" data-i18n="pauseBtn">
                            ⏸️ إيقاف مؤقت للزيادة (للعب على ستيم)
                        </button>

                        <button class="btn btn-danger" onclick="deleteCurrentAccount()" data-i18n="deleteAccountBtn">🗑️ إزالة هذا الحساب من البرنامج</button>
                    </div>
                </div>

            <!-- Live Logs -->
            <div class="section-box">
                <h2 data-i18n="logsTitle">📜 سجل العمليات المباشر (Live Logs)</h2>
                <div class="logs-box" id="logsBox"></div>
            </div>

            <!-- Footer Credits -->
            <div class="footer-credit">
                <div data-i18n="footerCredit">Steam Hour Booster & Launcher &bull; Developed by <strong>Ahmad</strong> &bull; All Rights Reserved</div>
                <div style="margin-top: 8px;">
                    <a href="https://t.me/u9955" target="_blank" style="color: #38bdf8; text-decoration: none; font-weight: bold; display: inline-flex; align-items: center; gap: 6px;">
                        <span data-i18n="footerTg">✈️ تليجرام المطور: @u9955</span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Modal: Add New Account (QR Code + Password Tabs) -->
        <div id="addAccModal" class="modal-overlay">
            <div class="modal-box" style="max-width: 460px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0; color: #38bdf8;" data-i18n="modalTitle">➕ إضافة حساب ستيم جديد</h3>
                    <button onclick="closeAddAccModal()" style="background: none; border: none; color: #9ca3af; font-size: 20px; cursor: pointer;">✕</button>
                </div>

                <!-- Tabs: QR Code vs Credentials -->
                <div style="display: flex; gap: 8px; margin-bottom: 20px;">
                    <button id="tabBtnQr" class="btn btn-primary" style="flex: 1; padding: 10px;" onclick="switchLoginTab('qr')" data-i18n="tabQr">📱 مسح الباركود (QR Code)</button>
                    <button id="tabBtnPass" class="btn" style="flex: 1; padding: 10px; background: #1f2937; color: #cbd5e1;" onclick="switchLoginTab('pass')" data-i18n="tabPass">⌨️ يوزر وباسورد</button>
                </div>

                <!-- Tab 1: QR Code -->
                <div id="loginTabQr" style="text-align: center;">
                    <div style="position: relative; display: inline-block; padding: 10px; background: #fff; border-radius: 14px; box-shadow: 0 0 25px rgba(56,189,248,0.25); margin-bottom: 15px;">
                        <img id="qrImg" src="" style="width: 220px; height: 220px; display: block; object-fit: contain;" alt="Steam QR Code">
                        <div id="qrLoadingOverlay" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(15,23,42,0.92); border-radius: 14px; display: flex; flex-direction: column; justify-content: center; align-items: center; color: #38bdf8;">
                            <div style="font-size: 26px; margin-bottom: 8px;">⏳</div>
                            <div style="font-size: 13px; font-weight: bold;" data-i18n="qrGen">جاري توليد الباركود...</div>
                        </div>
                    </div>

                    <div id="qrStatusText" style="font-size: 14px; font-weight: bold; color: #4ade80; margin-bottom: 12px;" data-i18n="qrWaiting">
                        في انتظار مسح الكود من تطبيق Steam...
                    </div>

                    <div style="background: #080c14; padding: 12px; border-radius: 10px; text-align: inherit; font-size: 12px; color: #9ca3af; line-height: 1.8; margin-bottom: 15px; border: 1px solid #1f2937;">
                        <div data-i18n="qrStep1">1️⃣ افتح <strong>تطبيق Steam</strong> على موبايلك.</div>
                        <div data-i18n="qrStep2">2️⃣ اضغط على أيقونة <strong>Steam Guard</strong> في الوسط.</div>
                        <div data-i18n="qrStep3">3️⃣ اختر <strong>"مسح رمز الاستجابة السريعة (QR)"</strong> ووجّه الكاميرا للشاشة.</div>
                        <div data-i18n="qrStep4">4️⃣ اضغط <strong>"تسجيل الدخول إلى Steam"</strong> في هاتفك.</div>
                    </div>

                    <button class="btn btn-primary" onclick="startQrLogin()" style="width: 100%;" data-i18n="qrRegen">🔄 إعادة توليد الباركود</button>
                </div>

                <!-- Tab 2: User / Password -->
                <div id="loginTabPass" style="display: none;">
                    <div class="form-group">
                        <label data-i18n="userLabel">اسم مستخدم الحساب (Steam Username):</label>
                        <input type="text" id="newAccUser" placeholder="Username" autocomplete="off">
                    </div>
                    <div class="form-group">
                        <label data-i18n="passLabel">كلمة المرور (Steam Password):</label>
                        <input type="password" id="newAccPass" placeholder="Password">
                    </div>
                    <div class="form-group" id="guardGroup" style="display: none;">
                        <label id="guardPromptLabel" style="color: #38bdf8; font-weight: bold;" data-i18n="guardLabel">كود التحقق (Steam Guard Code):</label>
                        <input type="text" id="newAccGuard" placeholder="Code (e.g. 5 letters or digits)">
                    </div>
                    <div style="display: flex; justify-content: flex-end; gap: 10px; margin-top: 20px;">
                        <button class="btn btn-danger" onclick="closeAddAccModal()" data-i18n="cancelBtn">إلغاء</button>
                        <button class="btn btn-primary" id="submitLoginBtn" onclick="submitNewAccount()" data-i18n="loginBtn">تسجيل الدخول</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            let currentAccounts = [];
            let activeAccountName = '';
            let gameInfoCache = {};
            let currentLang = localStorage.getItem('steam_booster_lang') || 'ar';

            const translations = {
                ar: {
                    langBtn: '🌐 English',
                    headerSub: 'نظام زيادة ساعات ألعاب ستيم المتقدم للحسابات المتعددة 24/7',
                    contactUs: 'تواصل معنا',
                    statSelectedAcc: 'الحساب المحدد',
                    statSteamID: 'معرف الحساب (SteamID)',
                    statGamesCount: 'ألعاب هذا الحساب',
                    statUptime: 'مدة التشغيل المستمرة',
                    addGameTitle: '➕ إضافة لعبة للحساب المحدد',
                    searchPlaceholder: 'ابحث باسم اللعبة (مثال: Rainbow, GTA, Rust, CS, Battlefield)...',
                    quickPicksLabel: 'أو اختر من أشهر الألعاب مباشرة بضغطة زر:',
                    activeGamesTitle: 'الألعاب المفعلة لهذا الحساب',
                    settingsTitle: '⚙️ إعدادات الحساب المحدد',
                    invisibleTitle: 'وضع التخفي (Invisible Mode)',
                    invisibleSub: 'إخفاء إشارة اللعبة الخضراء عن أصدقائك في هذا الحساب.',
                    deleteAccountBtn: '🗑️ إزالة هذا الحساب من البرنامج',
                    logsTitle: '📜 سجل العمليات المباشر (Live Logs)',
                    footerCredit: 'Steam Hour Booster & Launcher &bull; Developed by <strong>Ahmad</strong> &bull; All Rights Reserved',
                    footerTg: '✈️ تليجرام المطور: @u9955',
                    modalTitle: '➕ إضافة حساب ستيم جديد',
                    tabQr: '📱 مسح الباركود (QR Code)',
                    tabPass: '⌨️ يوزر وباسورد',
                    qrGen: 'جاري توليد الباركود...',
                    qrWaiting: 'في انتظار مسح الكود من تطبيق Steam... 📱',
                    qrStep1: '1️⃣ افتح <strong>تطبيق Steam</strong> على موبايلك.',
                    qrStep2: '2️⃣ اضغط على أيقونة <strong>Steam Guard</strong> في الوسط.',
                    qrStep3: '3️⃣ اختر <strong>"مسح رمز الاستجابة السريعة (QR)"</strong> ووجّه الكاميرا للشاشة.',
                    qrStep4: '4️⃣ اضغط <strong>"تسجيل الدخول إلى Steam"</strong> في هاتفك.',
                    qrRegen: '🔄 إعادة توليد الباركود',
                    userLabel: 'اسم مستخدم الحساب (Steam Username):',
                    passLabel: 'كلمة المرور (Steam Password):',
                    guardLabel: 'كود التحقق (Steam Guard Code):',
                    cancelBtn: 'إلغاء',
                    loginBtn: 'تسجيل الدخول',
                    addNewAccount: '➕ إضافة حساب جديد',
                    gamesSuffix: ' ألعاب',
                    gamesLimit: ' من أصل 32 لعبة',
                    noGames: 'لا توجد ألعاب مضافة لهذا الحساب حالياً. استخدم البحث لإضافة ألعاب!',
                    noAccountSelected: 'اضغط على "إضافة حساب جديد" لبدء التشغيل!',
                    boostingNow: 'الساعات تحسب الآن 🔥',
                    removeBtn: 'حذف ❌',
                    none: 'لا يوجد',
                    connected: 'متصل',
                    connecting: 'جاري الاتصال...',
                    confirmRemoveGame: 'هل أنت متأكد من إزالة اللعبة',
                    confirmDeleteAccount: 'هل تريد فعلاً إزالة الحساب',
                    loginSuccess: '✅ تم تسجيل دخول الحساب بنجاح!',
                    loginFailed: '❌ خطأ: ',
                    qrSuccess: '✅ تم تسجيل الدخول بنجاح!',
                    qrExpired: 'انتهت صلاحية الرمز',
                    qrFailed: 'فشل توليد الباركود',
                    selectAccountFirst: 'الرجاء اختيار أو إضافة حساب أولاً',
                    enterUser: 'الرجاء إدخال اسم المستخدم',
                    noSearchResults: 'لم يتم العثور على ألعاب مطابقة',
                    pauseBtn: '⏸️ إيقاف مؤقت للزيادة (للعب على ستيم)',
                    resumeBtn: '▶️ استئناف الزيادة (تشغيل الألعاب)',
                    pausedStatus: 'متوقف مؤقتاً ⏸️',
                    activeStatus: 'نشط ويحسب الآن 🔥'
                },
                en: {
                    langBtn: '🌐 العربية',
                    headerSub: 'Continuous 24/7 Steam Hours Booster & Multi-Account Idler',
                    contactUs: 'Contact Us',
                    statSelectedAcc: 'Selected Account',
                    statSteamID: 'SteamID',
                    statGamesCount: 'Account Games',
                    statUptime: 'Continuous Uptime',
                    addGameTitle: '➕ Add Game to Selected Account',
                    searchPlaceholder: 'Search by game name (e.g. Rainbow, GTA, Rust, CS, Battlefield)...',
                    quickPicksLabel: 'Or choose popular games instantly:',
                    activeGamesTitle: 'Active Games for this Account',
                    settingsTitle: '⚙️ Selected Account Settings',
                    invisibleTitle: 'Invisible Mode',
                    invisibleSub: 'Hide in-game green status from your Steam friends.',
                    deleteAccountBtn: '🗑️ Remove Account from Booster',
                    logsTitle: '📜 Live Operation Logs',
                    footerCredit: 'Steam Hour Booster & Launcher &bull; Developed by <strong>Ahmad</strong> &bull; All Rights Reserved',
                    footerTg: '✈️ Developer Telegram: @u9955',
                    modalTitle: '➕ Add New Steam Account',
                    tabQr: '📱 QR Code Login',
                    tabPass: '⌨️ Username & Password',
                    qrGen: 'Generating QR Code...',
                    qrWaiting: 'Waiting for scan from Steam Mobile App... 📱',
                    qrStep1: '1️⃣ Open <strong>Steam App</strong> on your phone.',
                    qrStep2: '2️⃣ Tap the <strong>Steam Guard</strong> icon in the middle.',
                    qrStep3: '3️⃣ Select <strong>"Scan a QR Code"</strong> and point camera at screen.',
                    qrStep4: '4️⃣ Tap <strong>"Sign in to Steam"</strong> on your phone.',
                    qrRegen: '🔄 Regenerate QR Code',
                    userLabel: 'Steam Username:',
                    passLabel: 'Steam Password:',
                    guardLabel: 'Steam Guard Code:',
                    cancelBtn: 'Cancel',
                    loginBtn: 'Sign In',
                    addNewAccount: '➕ Add New Account',
                    gamesSuffix: ' games',
                    gamesLimit: ' of 32 games',
                    noGames: 'No games added to this account yet. Use search to add games!',
                    noAccountSelected: 'Click "Add New Account" to get started!',
                    boostingNow: 'Hours boosting now 🔥',
                    removeBtn: 'Remove ❌',
                    none: 'None',
                    connected: 'Connected',
                    connecting: 'Connecting...',
                    confirmRemoveGame: 'Are you sure you want to remove game',
                    confirmDeleteAccount: 'Are you sure you want to remove account',
                    loginSuccess: '✅ Account logged in successfully!',
                    loginFailed: '❌ Error: ',
                    qrSuccess: '✅ Successfully logged in!',
                    qrExpired: 'QR Code expired',
                    qrFailed: 'Failed to generate QR Code',
                    selectAccountFirst: 'Please select or add an account first',
                    enterUser: 'Please enter your username',
                    noSearchResults: 'No matching games found',
                    pauseBtn: '⏸️ Pause Boosting (to Play on Steam)',
                    resumeBtn: '▶️ Resume Boosting',
                    pausedStatus: 'Paused ⏸️',
                    activeStatus: 'Active & Boosting 🔥'
                }
            };

            function applyLanguage(lang) {
                currentLang = lang;
                localStorage.setItem('steam_booster_lang', lang);
                const t = translations[lang] || translations.ar;

                document.documentElement.lang = lang;
                document.documentElement.dir = (lang === 'ar' ? 'rtl' : 'ltr');
                document.body.style.fontFamily = (lang === 'ar' ? "'Tajawal', sans-serif" : "'Segoe UI', Roboto, sans-serif");

                document.querySelectorAll('[data-i18n]').forEach(el => {
                    const key = el.getAttribute('data-i18n');
                    if (t[key]) {
                        el.innerHTML = t[key];
                    }
                });

                const searchInput = document.getElementById('gameSearchInput');
                if (searchInput && t.searchPlaceholder) {
                    searchInput.placeholder = t.searchPlaceholder;
                }

                const langBtn = document.getElementById('langToggleBtn');
                if (langBtn) {
                    langBtn.innerHTML = '<span>' + t.langBtn + '</span>';
                }

                renderAccountTabs();
                renderActiveAccountDetails();
            }

            function toggleLanguage() {
                applyLanguage(currentLang === 'ar' ? 'en' : 'ar');
            }

            function handleImgError(img, id) {
                if (!img.dataset.step) {
                    img.dataset.step = '1';
                    img.src = 'https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/' + id + '/header.jpg';
                } else if (img.dataset.step === '1') {
                    img.dataset.step = '2';
                    img.src = 'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/' + id + '/capsule_616x353.jpg';
                } else if (img.dataset.step === '2') {
                    img.dataset.step = '3';
                    img.src = 'https://cdn.cloudflare.steamstatic.com/steam/apps/' + id + '/header.jpg';
                } else {
                    img.src = 'https://dummyimage.com/460x215/1f2937/38bdf8.png&text=AppID+' + id;
                }
            }

            async function fetchStatus() {
                try {
                    const res = await fetch('/api/status');
                    const data = await res.json();
                    currentAccounts = data.accounts || [];

                    if (currentAccounts.length > 0 && (!activeAccountName || !currentAccounts.some(a => a.accountName === activeAccountName))) {
                        activeAccountName = currentAccounts[0].accountName;
                    }

                    renderAccountTabs();
                    renderActiveAccountDetails();

                    const logsBox = document.getElementById('logsBox');
                    logsBox.innerHTML = (data.logs || []).map(l => '<div>' + l + '</div>').join('');
                } catch (e) {
                    console.error('Status fetch error:', e);
                }
            }

            function renderAccountTabs() {
                const bar = document.getElementById('accountsTabsBar');
                const t = translations[currentLang] || translations.ar;
                let html = currentAccounts.map(acc => {
                    const isActive = acc.accountName === activeAccountName;
                    const dotClass = acc.connected ? (acc.paused ? 'dot-yellow' : 'dot-green') : 'dot-red';
                    const pauseBadge = acc.paused ? ' ⏸️' : '';
                    return '<button class="acc-tab ' + (isActive ? 'active' : '') + '" onclick="selectAccount(\\'' + acc.accountName + '\\')">' +
                        '<span class="dot ' + dotClass + '"></span>' +
                        '<span>👤 ' + acc.accountName + pauseBadge + '</span>' +
                        '<span style="font-size: 11px; opacity: 0.8;">(' + acc.games.length + t.gamesSuffix + ')</span>' +
                    '</button>';
                }).join('');

                html += '<button class="add-acc-btn" onclick="openAddAccModal()">' + t.addNewAccount + '</button>';
                bar.innerHTML = html;
            }

            function selectAccount(name) {
                activeAccountName = name;
                renderAccountTabs();
                renderActiveAccountDetails();
            }

            function renderActiveAccountDetails() {
                const t = translations[currentLang] || translations.ar;
                const acc = currentAccounts.find(a => a.accountName === activeAccountName);
                if (!acc) {
                    document.getElementById('selectedAccName').innerText = t.none;
                    document.getElementById('accSteamID').innerText = '--';
                    document.getElementById('gamesCount').innerText = '0';
                    document.getElementById('uptimeVal').innerText = '00:00:00';
                    document.getElementById('gamesGrid').innerHTML = '<div style="color: #9ca3af; padding: 20px; grid-column: 1/-1; text-align: center;">' + t.noAccountSelected + '</div>';
                    return;
                }

                document.getElementById('selectedAccName').innerText = acc.accountName;
                document.getElementById('accSteamID').innerText = acc.steamID || (acc.connected ? t.connected : t.connecting);
                document.getElementById('gamesCount').innerText = acc.games.length + ' / 32';
                document.getElementById('gamesLimitTxt').innerText = '(' + acc.games.length + t.gamesLimit + ')';
                document.getElementById('invisibleToggle').checked = acc.invisible;

                const pauseBtn = document.getElementById('pauseToggleBtn');
                if (pauseBtn) {
                    if (acc.paused) {
                        pauseBtn.innerText = t.resumeBtn;
                        pauseBtn.style.background = 'rgba(34, 197, 94, 0.2)';
                        pauseBtn.style.color = '#4ade80';
                        pauseBtn.style.borderColor = '#22c55e';
                    } else {
                        pauseBtn.innerText = t.pauseBtn;
                        pauseBtn.style.background = 'rgba(234, 179, 8, 0.2)';
                        pauseBtn.style.color = '#facc15';
                        pauseBtn.style.borderColor = '#eab308';
                    }
                }

                const h = Math.floor(acc.uptimeSeconds / 3600);
                const m = Math.floor((acc.uptimeSeconds % 3600) / 60);
                const s = acc.uptimeSeconds % 60;
                document.getElementById('uptimeVal').innerText = 
                    (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;

                const grid = document.getElementById('gamesGrid');
                if (!acc.games || acc.games.length === 0) {
                    grid.innerHTML = '<div style="color: #9ca3af; padding: 20px; grid-column: 1/-1; text-align: center;">' + t.noGames + '</div>';
                    return;
                }

                const boostingTxt = acc.paused ? t.pausedStatus : t.boostingNow;

                grid.innerHTML = acc.games.map(id => {
                    const cached = gameInfoCache[id];
                    const name = cached ? cached.name : ('AppID: ' + id);
                    const imgUrl = cached ? cached.image : ('https://shared.akamai.steamstatic.com/store_item_assets/steam/apps/' + id + '/header.jpg');

                    return '<div class="game-card">' +
                        '<img id="game-img-' + id + '" src="' + imgUrl + '" onerror="handleImgError(this, ' + id + ')">' +
                        '<div class="game-card-body">' +
                            '<div>' +
                                '<div class="game-card-title" id="game-title-' + id + '">' + name + '</div>' +
                                '<div class="game-card-sub">AppID: ' + id + ' &bull; ' + boostingTxt + '</div>' +
                            '</div>' +
                            '<button class="btn btn-danger" onclick="removeGame(' + id + ')">' + t.removeBtn + '</button>' +
                        '</div>' +
                    '</div>';
                }).join('');

                acc.games.forEach(id => {
                    if (!gameInfoCache[id]) {
                        fetch('/api/game-info/' + id)
                            .then(r => r.json())
                            .then(info => {
                                if (info) {
                                    gameInfoCache[id] = info;
                                    const titleEl = document.getElementById('game-title-' + id);
                                    const imgEl = document.getElementById('game-img-' + id);
                                    if (titleEl && info.name) titleEl.innerText = info.name;
                                    if (imgEl && info.image) imgEl.src = info.image;
                                }
                            })
                            .catch(() => {});
                    }
                });
            }

            async function addGame(appid) {
                const t = translations[currentLang] || translations.ar;
                if (!activeAccountName) return alert(t.selectAccountFirst);
                try {
                    const res = await fetch('/api/games/add', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ accountName: activeAccountName, appid: appid })
                    });
                    const data = await res.json();
                    if (data.error) alert(data.error);
                    fetchStatus();
                } catch (e) {
                    alert('Error: ' + e.message);
                }
            }

            async function removeGame(appid) {
                const t = translations[currentLang] || translations.ar;
                if (!activeAccountName) return;
                if (!confirm(t.confirmRemoveGame + ' (AppID: ' + appid + ')?')) return;
                try {
                    await fetch('/api/games/remove', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ accountName: activeAccountName, appid: appid })
                    });
                    fetchStatus();
                } catch (e) {
                    alert('Error: ' + e.message);
                }
            }

            async function toggleInvisible(val) {
                if (!activeAccountName) return;
                try {
                    await fetch('/api/settings', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ accountName: activeAccountName, invisible: val })
                    });
                    fetchStatus();
                } catch (e) {}
            }

            async function deleteCurrentAccount() {
                const t = translations[currentLang] || translations.ar;
                if (!activeAccountName) return;
                if (!confirm(t.confirmDeleteAccount + ' (' + activeAccountName + ')?')) return;
                try {
                    await fetch('/api/accounts/remove', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ accountName: activeAccountName })
                    });
                    activeAccountName = '';
                    fetchStatus();
                } catch (e) {
                    alert(e.message);
                }
            }

            let qrPollInterval = null;

            function switchLoginTab(tab) {
                const qrTab = document.getElementById('loginTabQr');
                const passTab = document.getElementById('loginTabPass');
                const btnQr = document.getElementById('tabBtnQr');
                const btnPass = document.getElementById('tabBtnPass');

                if (tab === 'qr') {
                    qrTab.style.display = 'block';
                    passTab.style.display = 'none';
                    btnQr.className = 'btn btn-primary';
                    btnPass.className = 'btn';
                    btnPass.style.background = '#1f2937';
                    btnPass.style.color = '#cbd5e1';
                    startQrLogin();
                } else {
                    qrTab.style.display = 'none';
                    passTab.style.display = 'block';
                    btnPass.className = 'btn btn-primary';
                    btnQr.className = 'btn';
                    btnQr.style.background = '#1f2937';
                    btnQr.style.color = '#cbd5e1';
                    if (qrPollInterval) clearInterval(qrPollInterval);
                }
            }

            async function startQrLogin() {
                const t = translations[currentLang] || translations.ar;
                const overlay = document.getElementById('qrLoadingOverlay');
                const qrImg = document.getElementById('qrImg');
                const statusText = document.getElementById('qrStatusText');

                overlay.style.display = 'flex';
                statusText.innerText = t.qrGen;
                statusText.style.color = '#38bdf8';

                if (qrPollInterval) clearInterval(qrPollInterval);

                try {
                    const res = await fetch('/api/qr/start');
                    const data = await res.json();
                    if (data.success && data.challengeUrl) {
                        qrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=8&data=' + encodeURIComponent(data.challengeUrl);
                        qrImg.onload = () => { overlay.style.display = 'none'; };
                        statusText.innerText = t.qrWaiting;
                        statusText.style.color = '#4ade80';

                        qrPollInterval = setInterval(async () => {
                            try {
                                const stRes = await fetch('/api/qr/status');
                                const st = await stRes.json();
                                if (st.state === 'authenticated') {
                                    clearInterval(qrPollInterval);
                                    statusText.innerText = t.qrSuccess;
                                    statusText.style.color = '#22c55e';
                                    setTimeout(() => {
                                        closeAddAccModal();
                                        activeAccountName = st.accountName;
                                        fetchStatus();
                                    }, 1200);
                                } else if (st.state === 'timeout' || st.state === 'error') {
                                    clearInterval(qrPollInterval);
                                    statusText.innerText = st.error || t.qrExpired;
                                    statusText.style.color = '#ef4444';
                                }
                            } catch (e) {}
                        }, 1500);
                    } else {
                        statusText.innerText = t.qrFailed;
                        statusText.style.color = '#ef4444';
                    }
                } catch (e) {
                    statusText.innerText = 'Error: ' + e.message;
                    statusText.style.color = '#ef4444';
                }
            }

            function openAddAccModal() {
                const t = translations[currentLang] || translations.ar;
                document.getElementById('newAccUser').value = '';
                document.getElementById('newAccPass').value = '';
                document.getElementById('newAccGuard').value = '';
                document.getElementById('guardGroup').style.display = 'none';
                document.getElementById('submitLoginBtn').innerText = t.loginBtn;
                document.getElementById('addAccModal').style.display = 'flex';
                switchLoginTab('qr');
            }

            function closeAddAccModal() {
                if (qrPollInterval) clearInterval(qrPollInterval);
                document.getElementById('addAccModal').style.display = 'none';
            }

            async function submitNewAccount() {
                const t = translations[currentLang] || translations.ar;
                const user = document.getElementById('newAccUser').value.trim();
                const pass = document.getElementById('newAccPass').value.trim();
                const guard = document.getElementById('newAccGuard').value.trim();

                if (!user) return alert(t.enterUser);

                const btn = document.getElementById('submitLoginBtn');
                btn.innerText = t.connecting;

                try {
                    const res = await fetch('/api/accounts/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ accountName: user, password: pass, guardCode: guard })
                    });
                    const data = await res.json();

                    if (data.status === 'need_guard') {
                        document.getElementById('guardGroup').style.display = 'block';
                        document.getElementById('guardPromptLabel').innerText = data.message;
                        btn.innerText = (currentLang === 'ar' ? 'تأكيد الكود والدخول' : 'Confirm Code & Sign In');
                        alert(data.message);
                    } else if (data.status === 'success') {
                        alert(t.loginSuccess);
                        closeAddAccModal();
                        activeAccountName = data.accountName;
                        fetchStatus();
                    } else if (data.status === 'authenticating') {
                        btn.innerText = (currentLang === 'ar' ? 'جاري التحقق والدخول...' : 'Verifying & Signing In...');
                        setTimeout(() => {
                            closeAddAccModal();
                            activeAccountName = user;
                            fetchStatus();
                        }, 2000);
                    } else if (data.error) {
                        alert(t.loginFailed + data.error);
                        btn.innerText = t.loginBtn;
                    }
                } catch (e) {
                    alert('Error: ' + e.message);
                    btn.innerText = t.loginBtn;
                }
            }

            let searchTimeout;
            const searchInput = document.getElementById('gameSearchInput');
            const searchResults = document.getElementById('searchResults');

            searchInput.addEventListener('input', (e) => {
                const t = translations[currentLang] || translations.ar;
                clearTimeout(searchTimeout);
                const q = e.target.value.trim();
                if (q.length < 2) {
                    searchResults.style.display = 'none';
                    return;
                }

                searchTimeout = setTimeout(async () => {
                    try {
                        const res = await fetch('/api/search?q=' + encodeURIComponent(q));
                        const data = await res.json();
                        if (data.items && data.items.length > 0) {
                            searchResults.innerHTML = data.items.map(item => {
                                return '<div class="search-item">' +
                                    '<div class="search-item-info">' +
                                        '<img src="' + (item.tiny_image || '') + '" onerror="this.style.display=\\'none\\'">' +
                                        '<div>' +
                                            '<strong>' + item.name + '</strong>' +
                                            '<div style="font-size: 11px; color: #9ca3af;">AppID: ' + item.id + '</div>' +
                                        '</div>' +
                                    '</div>' +
                                    '<button class="btn btn-primary" onclick="addGame(' + item.id + '); searchResults.style.display=\\'none\\'; searchInput.value=\\'\\';">+ ' + (currentLang === 'ar' ? 'إضافة' : 'Add') + '</button>' +
                                '</div>';
                            }).join('');
                            searchResults.style.display = 'block';
                        } else {
                            searchResults.innerHTML = '<div style="padding: 15px; color: #9ca3af; text-align: center;">' + t.noSearchResults + '</div>';
                            searchResults.style.display = 'block';
                        }
                    } catch (err) {}
                }, 350);
            });

            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                    searchResults.style.display = 'none';
                }
            });

            async function togglePauseCurrentAccount() {
                if (!activeAccountName) return;
                try {
                    const res = await fetch('/api/accounts/toggle-pause', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ accountName: activeAccountName })
                    });
                    const data = await res.json();
                    fetchStatus();
                } catch (e) {
                    alert('Error: ' + e.message);
                }
            }

            // Initialize Language & Polling
            applyLanguage(currentLang);
            fetchStatus();
            setInterval(fetchStatus, 2500);
        </script>
    </body>
    </html>
    `);
});

// -------------------------------------------------------------
// 2. Start Bot and Server
// -------------------------------------------------------------
async function init() {
    console.log('===================================================');
    console.log('             Steam Hour Booster 24/7               ');
    console.log('               Developed by Ahmad                  ');
    console.log('===================================================');

    await new Promise(resolve => {
        const server = app.listen(PORT, () => {
            console.log(`[Launcher] Running at http://localhost:${PORT}`);
            console.log('👑 Developer: Ahmad');
            console.log('---------------------------------------------------');
            resolve();
        });

        server.on('error', (err) => {
            if (err.code === 'EADDRINUSE') {
                console.log('\n[!] Steam Booster is ALREADY running in the background!');
                console.log('[!] Opening the launcher window now...');
                exec(`start http://localhost:${PORT}`);
                setTimeout(() => process.exit(0), 1000);
            } else {
                console.error('Server error:', err.message);
            }
        });
    });

    // Start bots for existing accounts
    if (config.accounts && config.accounts.length > 0) {
        config.accounts.forEach(acc => {
            startBotForAccount(acc);
        });
    } else {
        addGlobalLog('No accounts configured yet. Use the launcher at http://localhost:3000 to add an account!');
    }
}

init();
