using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace SteamHourBooster
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            string appDir = AppDomain.CurrentDomain.BaseDirectory;
            Directory.SetCurrentDirectory(appDir);

            // 1. Check if server is already responding
            bool serverReady = false;
            try
            {
                var req = (HttpWebRequest)WebRequest.Create("http://localhost:3000/api/status");
                req.Timeout = 1000;
                using (var resp = req.GetResponse())
                {
                    serverReady = true;
                }
            }
            catch { }

            // 2. If not running, launch node silently in background
            if (!serverReady)
            {
                ProcessStartInfo nodePsi = new ProcessStartInfo();
                nodePsi.FileName = "node.exe";
                nodePsi.Arguments = "index.js";
                nodePsi.WorkingDirectory = appDir;
                nodePsi.WindowStyle = ProcessWindowStyle.Hidden;
                nodePsi.CreateNoWindow = true;
                nodePsi.UseShellExecute = false;

                try
                {
                    Process.Start(nodePsi);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Could not launch Node.js: " + ex.Message, "Steam Booster", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                for (int i = 0; i < 20; i++)
                {
                    Thread.Sleep(300);
                    try
                    {
                        var req = (HttpWebRequest)WebRequest.Create("http://localhost:3000/api/status");
                        req.Timeout = 800;
                        using (var resp = req.GetResponse())
                        {
                            serverReady = true;
                            break;
                        }
                    }
                    catch { }
                }
            }

            // 3. Launch Standalone Native Window (App Mode)
            string edgePath = @"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe";
            if (!File.Exists(edgePath))
            {
                edgePath = @"C:\Program Files\Microsoft\Edge\Application\msedge.exe";
            }

            if (File.Exists(edgePath))
            {
                ProcessStartInfo edgePsi = new ProcessStartInfo();
                edgePsi.FileName = edgePath;
                edgePsi.Arguments = "--app=http://localhost:3000 --window-size=980,840";
                Process.Start(edgePsi);
            }
            else
            {
                Process.Start("http://localhost:3000");
            }
        }
    }
}
